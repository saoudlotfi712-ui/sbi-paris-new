"use client";

import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  Heart,
  LockKeyhole,
  Minus,
  Plus,
  RefreshCcw,
  ShoppingBag,
  Truck,
  Zap,
} from "lucide-react";
import {
  type MouseEvent,
  useCallback,
  useMemo,
  useState,
} from "react";

import styles from "./page.module.css";

const PRODUCT_IMAGES = Array.from(
  { length: 8 },
  (_, index) =>
    `/products/chaussures-sport-homme/${index + 1}.webp`,
);

const PRODUCT_SIZES = [
  38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48,
];

type ProductColor = {
  id: "black" | "white" | "brown";
  label: string;
  className: string;
};

const PRODUCT_COLORS: ProductColor[] = [
  {
    id: "black",
    label: "Noir",
    className: styles.black,
  },
  {
    id: "white",
    label: "Blanc",
    className: styles.white,
  },
  {
    id: "brown",
    label: "Marron",
    className: styles.brown,
  },
];

export default function ProductPage() {
  const router = useRouter();

  const [selectedImage, setSelectedImage] = useState(
    PRODUCT_IMAGES[0],
  );

  const [selectedSize, setSelectedSize] = useState(40);
  const [selectedColor, setSelectedColor] =
    useState<ProductColor["id"]>("black");
  const [quantity, setQuantity] = useState(1);
  const [isFavorite, setIsFavorite] = useState(false);
  const [isZooming, setIsZooming] = useState(false);

  const [zoomPosition, setZoomPosition] = useState({
    x: 50,
    y: 50,
  });

  const selectedColorData = useMemo(
    () =>
      PRODUCT_COLORS.find(
        (color) => color.id === selectedColor,
      ) ?? PRODUCT_COLORS[0],
    [selectedColor],
  );

  const decreaseQuantity = useCallback(() => {
    setQuantity((currentQuantity) =>
      Math.max(1, currentQuantity - 1),
    );
  }, []);

  const increaseQuantity = useCallback(() => {
    setQuantity((currentQuantity) =>
      Math.min(10, currentQuantity + 1),
    );
  }, []);

  const handleZoomMove = useCallback(
    (event: MouseEvent<HTMLDivElement>) => {
      const bounds =
        event.currentTarget.getBoundingClientRect();

      const x =
        ((event.clientX - bounds.left) / bounds.width) * 100;

      const y =
        ((event.clientY - bounds.top) / bounds.height) * 100;

      setZoomPosition({
        x: Math.max(0, Math.min(100, x)),
        y: Math.max(0, Math.min(100, y)),
      });
    },
    [],
  );

  const handleAddToCart = useCallback(() => {
    const savedCart = localStorage.getItem("sbi-cart");

    const cart = savedCart ? JSON.parse(savedCart) : [];

    const newProduct = {
      id: "chaussure-sport-homme",
      name: "Chaussure Sport Homme",
      price: "89.90",
      image: selectedImage,
      size: selectedSize,
      color: selectedColorData.label,
      quantity,
    };

    const existingProduct = cart.find(
      (item: {
        id: string;
        size?: number;
        color?: string;
      }) =>
        item.id === newProduct.id &&
        item.size === newProduct.size &&
        item.color === newProduct.color,
    );

    if (existingProduct) {
      existingProduct.quantity += quantity;
    } else {
      cart.push(newProduct);
    }

    localStorage.setItem(
      "sbi-cart",
      JSON.stringify(cart),
    );

    window.dispatchEvent(
      new Event("sbi-cart-updated"),
    );
  }, [
    quantity,
    selectedColorData.label,
    selectedImage,
    selectedSize,
  ]);

  const handleBuyNow = useCallback(() => {
    const checkoutProduct = {
      id: "chaussure-sport-homme",
      name: "Chaussure Sport Homme",
      image: selectedImage,
      price: 89.9,
      size: selectedSize,
      color: selectedColorData.label,
      colorId: selectedColor,
      quantity,
    };

    localStorage.setItem(
      "checkoutProduct",
      JSON.stringify(checkoutProduct),
    );

    router.push("/checkout");
  }, [
    quantity,
    router,
    selectedColor,
    selectedColorData.label,
    selectedImage,
    selectedSize,
  ]);

  return (
    <main className={styles.page}>
      <div className={styles.container}>
        <nav
          className={styles.breadcrumb}
          aria-label="Fil d’Ariane"
        >
          <Link href="/">Accueil</Link>
          <span>/</span>

          <Link href="/homme">Homme</Link>

          <span>/</span>

          <Link href="/univers-sport-homme">
            Chaussures de sport
          </Link>

          <span>/</span>

          <span>Chaussure Sport Homme</span>
        </nav>

        <section className={styles.productLayout}>
          <div
            className={styles.thumbnails}
            aria-label="Images du produit"
          >
            {PRODUCT_IMAGES.map((image, index) => {
              const isActive = selectedImage === image;

              return (
                <button
                  key={image}
                  type="button"
                  className={`${styles.thumbnailButton} ${
                    isActive ? styles.thumbnailActive : ""
                  }`}
                  onClick={() => setSelectedImage(image)}
                >
                  <Image
                    src={image}
                    alt={`Vue ${index + 1}`}
                    width={82}
                    height={82}
                  />
                </button>
              );
            })}
          </div>

          <div
            className={styles.mainImageBox}
            onMouseEnter={() => setIsZooming(true)}
            onMouseLeave={() => setIsZooming(false)}
            onMouseMove={handleZoomMove}
          >
            <span className={styles.newBadge}>
              NOUVEAU
            </span>

            <Image
              src={selectedImage}
              alt="Chaussure Sport Homme"
              width={900}
              height={900}
              priority
              className={styles.mainProductImage}
              style={{
                opacity: isZooming ? 0 : 1,
              }}
            />

            {isZooming && (
              <div
                style={{
                  position: "absolute",
                  inset: 0,
                  backgroundImage: `url("${selectedImage}")`,
                  backgroundRepeat: "no-repeat",
                  backgroundSize: "220%",
                  backgroundPosition: `${zoomPosition.x}% ${zoomPosition.y}%`,
                }}
              />
            )}
          </div>

          <div className={styles.productInfo}>
            <h1 className={styles.title}>
              Chaussure Sport Homme
            </h1>

            <div className={styles.rating}>
              <span className={styles.stars}>
                ★★★★★
              </span>

              <span className={styles.reviewCount}>
                (125 avis)
              </span>
            </div>

            <p className={styles.price}>89,90 €</p>

            <p className={styles.description}>
              Chaussure sportive confortable,
              légère et élégante conçue pour
              accompagner vos journées.
            </p>

            <div className={styles.separator} />

            <h2 className={styles.optionTitle}>
              COULEUR :
              <span> {selectedColorData.label}</span>
            </h2>

            <div className={styles.colors}>
              {PRODUCT_COLORS.map((color) => (
                <button
                  key={color.id}
                  type="button"
                  aria-label={color.label}
                  className={`${styles.colorButton} ${
                    color.className
                  } ${
                    selectedColor === color.id
                      ? styles.colorActive
                      : ""
                  }`}
                  onClick={() =>
                    setSelectedColor(color.id)
                  }
                />
              ))}
            </div>

            <div className={styles.sizeHeading}>
              <h2 className={styles.optionTitle}>
                TAILLE :
              </h2>

              <Link
                href="/tableau-des-tailles"
                className={styles.sizeGuide}
              >
                Tableau des tailles
              </Link>
            </div>

            <div className={styles.sizes}>
              {PRODUCT_SIZES.map((size) => (
                <button
                  key={size}
                  type="button"
                  className={`${styles.sizeButton} ${
                    selectedSize === size
                      ? styles.sizeActive
                      : ""
                  }`}
                  onClick={() => setSelectedSize(size)}
                >
                  {size}
                </button>
              ))}
            </div>

            <div className={styles.quantitySection}>
              <h2 className={styles.optionTitle}>
                QUANTITÉ :
              </h2>

              <div className={styles.quantity}>
                <button
                  type="button"
                  onClick={decreaseQuantity}
                  disabled={quantity === 1}
                  aria-label="Diminuer la quantité"
                >
                  <Minus size={17} />
                </button>

                <span>{quantity}</span>

                <button
                  type="button"
                  onClick={increaseQuantity}
                  disabled={quantity === 10}
                  aria-label="Augmenter la quantité"
                >
                  <Plus size={17} />
                </button>
              </div>
            </div>

            <div className={styles.actions}>
              <button
                type="button"
                className={styles.addToCart}
                onClick={handleAddToCart}
              >
                <ShoppingBag size={18} />
                Ajouter au panier
              </button>

              <button
                type="button"
                className={styles.favoriteButton}
                onClick={() =>
                  setIsFavorite((current) => !current)
                }
                aria-label="Ajouter aux favoris"
              >
                <Heart
                  size={22}
                  fill={
                    isFavorite
                      ? "currentColor"
                      : "none"
                  }
                />
              </button>

              <button
                type="button"
                className={styles.buyNow}
                onClick={handleBuyNow}
              >
                Acheter maintenant
              </button>
            </div>

            <div className={styles.services}>
              <div>
                <Truck size={22} />

                <span>
                  Livraison rapide
                  <small>24 à 72 h</small>
                </span>
              </div>

              <div>
                <RefreshCcw size={22} />

                <span>
                  Retour gratuit
                  <small>14 jours</small>
                </span>
              </div>

              <div>
                <LockKeyhole size={22} />

                <span>
                  Paiement sécurisé
                  <small>100 % sécurisé</small>
                </span>
              </div>
            </div>

            <div
              style={{
                marginTop: 24,
                padding: 18,
                border: "1px solid #e2e8f0",
                borderRadius: 10,
                background: "#fafafa",
              }}
            >
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 10,
                  fontWeight: 700,
                  color: "#0a1931",
                }}
              >
                <Zap size={18} />
                Pourquoi choisir SBI PARIS ?
              </div>

              <ul
                style={{
                  marginTop: 14,
                  paddingLeft: 18,
                  color: "#475569",
                  lineHeight: 1.8,
                }}
              >
                <li>Design moderne et élégant.</li>
                <li>
                  Confort exceptionnel au quotidien.
                </li>
                <li>Matériaux de haute qualité.</li>
                <li>
                  Livraison rapide partout en Europe.
                </li>
                <li>Paiement 100 % sécurisé.</li>
              </ul>
            </div>
          </div>
        </section>
      </div>
    </main>
  );
}